# dynamicRegression
Implementation of the experiments of "Dynamic Least-Squares Regression".

To run the experiments, run dyn_reg_algo.m, and set the hyperparameters according to hyperParameter.txt.
